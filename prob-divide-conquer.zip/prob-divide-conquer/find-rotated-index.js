function findRotatedIndex() {
 
}

module.exports = findRotatedIndex
function findFloor() {
  
}

module.exports = findFloor
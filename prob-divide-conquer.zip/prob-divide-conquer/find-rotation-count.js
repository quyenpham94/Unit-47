function findRotationCount() {
  
}

module.exports = findRotationCount
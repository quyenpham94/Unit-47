function countZeroes() {
  
}

module.exports = countZeroes